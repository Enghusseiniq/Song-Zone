package com.hussein.songzone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class SettingsActivity extends Activity {
    private SettingsManager settings;
    private Switch swSkipSilence, swGapless, swSleepTimer, swShowDuration, swShowIndex;
    private SeekBar sbGaplessSeconds;
    private TextView tvGaplessSecondsValue;
    private Spinner spSleepDuration;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_settings);
        settings = new SettingsManager(this);
        bindViews();
        loadValues();
        setupListeners();
    }

    private void bindViews() {
        swSkipSilence = findViewById(R.id.swSkipSilence);
        swGapless = findViewById(R.id.swGapless);
        swSleepTimer = findViewById(R.id.swSleepTimer);
        swShowDuration = findViewById(R.id.swShowDuration);
        swShowIndex = findViewById(R.id.swShowIndex);
        sbGaplessSeconds = findViewById(R.id.sbGaplessSeconds);
        tvGaplessSecondsValue = findViewById(R.id.tvGaplessSecondsValue);
        spSleepDuration = findViewById(R.id.spSleepDuration);

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        TextView tvVersion = findViewById(R.id.tvVersion);
        tvVersion.setText(getAppVersion());
    }

    private void loadValues() {
        swSkipSilence.setChecked(settings.isSkipSilenceEnabled());
        swGapless.setChecked(settings.isGaplessEnabled());
        int gs = settings.getGaplessSeconds();
        sbGaplessSeconds.setProgress(gs);
        updateGsLabel(gs);

        swSleepTimer.setChecked(settings.isSleepTimerEnabled());

        ArrayAdapter<CharSequence> a = ArrayAdapter.createFromResource(
                this, R.array.sleep_duration_labels, android.R.layout.simple_spinner_item);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spSleepDuration.setAdapter(a);

        int cm = settings.getSleepDurationMinutes();
        String[] vals = getResources().getStringArray(R.array.sleep_duration_values);
        for (int i = 0; i < vals.length; i++)
            if (Integer.parseInt(vals[i]) == cm) { spSleepDuration.setSelection(i); break; }

        swShowDuration.setChecked(settings.isShowDurationEnabled());
        swShowIndex.setChecked(settings.isShowIndexEnabled());
    }

    private void setupListeners() {
        swSkipSilence.setOnCheckedChangeListener((v, c) -> settings.setSkipSilenceEnabled(c));
        swGapless.setOnCheckedChangeListener((v, c) -> {
            settings.setGaplessEnabled(c);
            findViewById(R.id.rowGaplessSeconds).setVisibility(c ? View.VISIBLE : View.GONE);
        });
        sbGaplessSeconds.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) {
                updateGsLabel(p);
                if (u) settings.setGaplessSeconds(p);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {
                settings.setGaplessSeconds(sb.getProgress());
            }
        });
        swSleepTimer.setOnCheckedChangeListener((v, c) -> settings.setSleepTimerEnabled(c));
        spSleepDuration.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int i, long id) {
                String[] vals = getResources().getStringArray(R.array.sleep_duration_values);
                settings.setSleepDurationMinutes(Integer.parseInt(vals[i]));
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
        swShowDuration.setOnCheckedChangeListener((v, c) -> settings.setShowDurationEnabled(c));
        swShowIndex.setOnCheckedChangeListener((v, c) -> settings.setShowIndexEnabled(c));

        findViewById(R.id.rowGaplessSeconds)
                .setVisibility(settings.isGaplessEnabled() ? View.VISIBLE : View.GONE);

        View devRow = findViewById(R.id.btnDeveloper);
        if (devRow != null) devRow.setOnClickListener(v ->
                startActivity(new Intent(SettingsActivity.this, DeveloperActivity.class)));
    }

    private void updateGsLabel(int s) {
        if (s == 0) tvGaplessSecondsValue.setText("معطّل");
        else if (s == 1) tvGaplessSecondsValue.setText("ثانية واحدة");
        else if (s == 2) tvGaplessSecondsValue.setText("ثانيتان");
        else tvGaplessSecondsValue.setText(s + " ثوانٍ");
    }

    private String getAppVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "1.0"; }
    }
}
