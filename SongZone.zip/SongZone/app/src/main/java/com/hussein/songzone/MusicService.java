package com.hussein.songzone;

import android.app.*;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class MusicService extends Service implements MusicPlayerManager.Listener {
    private static final String TAG = "SongZone";
    private static final String CHANNEL_ID = "songzone_playback";
    private static final int NOTIF_ID = 1001;

    public static final String ACTION_TOGGLE = "com.hussein.songzone.TOGGLE";
    public static final String ACTION_NEXT   = "com.hussein.songzone.NEXT";
    public static final String ACTION_PREV   = "com.hussein.songzone.PREV";

    public interface Callback {
        void onProgress(int positionMs, int durationMs);
        void onSongChanged(Song song);
        void onPlaybackStateChanged(boolean isPlaying);
    }

    public class LocalBinder extends Binder {
        public MusicService getService() { return MusicService.this; }
    }

    private final IBinder binder = new LocalBinder();
    private MusicPlayerManager player;
    private final List<Song> playlist = new ArrayList<>();
    private int currentIndex = -1;
    private Callback callback;
    private boolean isForeground = false;

    @Override public void onCreate() {
        super.onCreate();
        player = new MusicPlayerManager(this);
        player.setListener(this);
        createNotificationChannel();
    }

    @Override public IBinder onBind(Intent i) { return binder; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case ACTION_TOGGLE: toggle(); break;
                case ACTION_NEXT: next(); break;
                case ACTION_PREV: previous(); break;
            }
        }
        return START_STICKY;
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
        if (cb != null) {
            Song cur = player.getCurrentSong();
            if (cur != null) cb.onSongChanged(cur);
            cb.onPlaybackStateChanged(player.isPlaying());
        }
    }

    public void playFromList(List<Song> list, int index) {
        if (list == null || list.isEmpty()) return;
        playlist.clear();
        playlist.addAll(list);
        playAt(index);
    }

    public void playAt(int index) {
        if (index < 0 || index >= playlist.size()) return;
        currentIndex = index;
        player.play(playlist.get(index));
    }

    public void toggle() {
        if (player.getCurrentSong() == null && !playlist.isEmpty()) { playAt(0); return; }
        player.toggle();
    }

    public void next() {
        if (playlist.isEmpty()) return;
        playAt(currentIndex < playlist.size() - 1 ? currentIndex + 1 : 0);
    }

    public void previous() {
        if (playlist.isEmpty()) return;
        playAt(currentIndex > 0 ? currentIndex - 1 : playlist.size() - 1);
    }

    public void seekTo(int ms) { player.seekTo(ms); }
    public MusicPlayerManager getPlayerManager() { return player; }
    public int getCurrentIndex() { return currentIndex; }
    public Song getCurrentSong() { return player.getCurrentSong(); }
    public boolean isPlaying() { return player.isPlaying(); }

    public void stopPlayback() {
        player.pause();
        if (isForeground) { stopForeground(true); isForeground = false; }
        stopSelf();
    }

    @Override public void onProgress(int p, int d) { if (callback != null) callback.onProgress(p, d); }
    @Override public void onSongStarted(Song s) {
        if (callback != null) callback.onSongChanged(s);
        showForegroundNotification(s);
    }
    @Override public void onPlaybackStateChanged(boolean playing) {
        if (callback != null) callback.onPlaybackStateChanged(playing);
        Song s = player.getCurrentSong();
        if (s != null) updateNotification(s);
    }
    @Override public void onSongCompleted(Song song) {
        switch (player.getRepeatMode()) {
            case ONE: player.replayCurrent(); break;
            case ALL: next(); break;
            case OFF:
                if (currentIndex < playlist.size() - 1) next();
                else stopPlayback();
                break;
        }
    }
    @Override public void onPlaybackError(String m) { Log.e(TAG, "err: " + m); }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "تشغيل الموسيقى", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private void showForegroundNotification(Song song) {
        Notification n = buildNotification(song);
        if (!isForeground) { startForeground(NOTIF_ID, n); isForeground = true; }
        else {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.notify(NOTIF_ID, n);
        }
    }

    private void updateNotification(Song song) {
        if (!isForeground) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification(song));
    }

    private Notification buildNotification(Song song) {
        Intent oi = new Intent(this, MainActivity.class);
        oi.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent cpi = PendingIntent.getActivity(this, 0, oi,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) b = new Notification.Builder(this, CHANNEL_ID);
        else b = new Notification.Builder(this);

        b.setSmallIcon(R.drawable.ic_notification)
         .setContentTitle(song.getTitle())
         .setContentText(song.getArtist())
         .setSubText("Song Zone")
         .setContentIntent(cpi)
         .setOngoing(player.isPlaying())
         .setOnlyAlertOnce(true)
         .setShowWhen(false)
         .setVisibility(Notification.VISIBILITY_PUBLIC)
         .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_previous,
                 "السابق", actionPi(ACTION_PREV, 1)).build())
         .addAction(new Notification.Action.Builder(
                 player.isPlaying() ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                 player.isPlaying() ? "إيقاف" : "تشغيل", actionPi(ACTION_TOGGLE, 2)).build())
         .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_next,
                 "التالي", actionPi(ACTION_NEXT, 3)).build());
        return b.build();
    }

    private PendingIntent actionPi(String action, int reqCode) {
        Intent i = new Intent(this, MusicService.class);
        i.setAction(action);
        return PendingIntent.getService(this, reqCode, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @Override public void onDestroy() {
        super.onDestroy();
        if (player != null) player.release();
        isForeground = false;
    }
}
