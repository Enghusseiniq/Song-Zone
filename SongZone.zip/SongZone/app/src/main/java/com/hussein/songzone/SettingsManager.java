package com.hussein.songzone;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsManager {
    private static final String PREFS_NAME = "songzone_settings";
    private static final String K_SKIP = "skip_silence";
    private static final String K_GAP = "gapless";
    private static final String K_GAP_SEC = "gapless_seconds";
    private static final String K_SLEEP = "sleep_enabled";
    private static final String K_SLEEP_DUR = "sleep_duration";
    private static final String K_SHOW_DUR = "show_duration";
    private static final String K_SHOW_IDX = "show_index";

    private final SharedPreferences prefs;
    public SettingsManager(Context c) {
        this.prefs = c.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public boolean isSkipSilenceEnabled() { return prefs.getBoolean(K_SKIP, false); }
    public void setSkipSilenceEnabled(boolean e) { prefs.edit().putBoolean(K_SKIP, e).apply(); }

    public boolean isGaplessEnabled() { return prefs.getBoolean(K_GAP, false); }
    public void setGaplessEnabled(boolean e) { prefs.edit().putBoolean(K_GAP, e).apply(); }

    public int getGaplessSeconds() {
        int v = prefs.getInt(K_GAP_SEC, 3);
        return Math.max(0, Math.min(10, v));
    }
    public void setGaplessSeconds(int s) {
        prefs.edit().putInt(K_GAP_SEC, Math.max(0, Math.min(10, s))).apply();
    }

    public boolean isSleepTimerEnabled() { return prefs.getBoolean(K_SLEEP, false); }
    public void setSleepTimerEnabled(boolean e) { prefs.edit().putBoolean(K_SLEEP, e).apply(); }

    public int getSleepDurationMinutes() {
        int v = prefs.getInt(K_SLEEP_DUR, 30);
        return Math.max(1, v);
    }
    public void setSleepDurationMinutes(int m) {
        prefs.edit().putInt(K_SLEEP_DUR, Math.max(1, m)).apply();
    }

    public boolean isShowDurationEnabled() { return prefs.getBoolean(K_SHOW_DUR, true); }
    public void setShowDurationEnabled(boolean e) { prefs.edit().putBoolean(K_SHOW_DUR, e).apply(); }

    public boolean isShowIndexEnabled() { return prefs.getBoolean(K_SHOW_IDX, true); }
    public void setShowIndexEnabled(boolean e) { prefs.edit().putBoolean(K_SHOW_IDX, e).apply(); }
}
