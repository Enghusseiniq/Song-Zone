package com.hussein.songzone;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.IOException;

public class MusicPlayerManager {
    private static final String TAG = "SongZone";

    public enum RepeatMode { OFF, ALL, ONE }

    public interface Listener {
        void onProgress(int positionMs, int durationMs);
        void onSongStarted(Song song);
        void onPlaybackStateChanged(boolean isPlaying);
        void onSongCompleted(Song song);
        void onPlaybackError(String message);
    }

    private final Context context;
    private final MediaPlayer player = new MediaPlayer();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable progressTask = new Runnable() {
        @Override public void run() {
            if (player != null && isPlaying() && listener != null)
                listener.onProgress(player.getCurrentPosition(), player.getDuration());
            handler.postDelayed(this, 1000);
        }
    };

    private Song currentSong;
    private RepeatMode repeatMode = RepeatMode.ALL;
    private boolean prepared = false;
    private Listener listener;

    public MusicPlayerManager(Context c) {
        this.context = c.getApplicationContext();
        player.setAudioAttributes(new AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .setUsage(AudioAttributes.USAGE_MEDIA).build());
        player.setOnPreparedListener(mp -> {
            prepared = true;
            mp.start();
            if (listener != null) {
                listener.onSongStarted(currentSong);
                listener.onPlaybackStateChanged(true);
                listener.onProgress(mp.getCurrentPosition(), mp.getDuration());
            }
            startProgressUpdates();
        });
        player.setOnCompletionListener(mp -> {
            prepared = false;
            stopProgressUpdates();
            if (listener != null && currentSong != null) listener.onSongCompleted(currentSong);
        });
        player.setOnErrorListener((mp, w, e) -> {
            prepared = false;
            stopProgressUpdates();
            Log.e(TAG, "MP error w=" + w + " e=" + e);
            if (listener != null) {
                listener.onPlaybackStateChanged(false);
                listener.onPlaybackError("MediaPlayer " + w + "/" + e);
            }
            return true;
        });
    }

    public void setListener(Listener l) { this.listener = l; }
    public RepeatMode getRepeatMode() { return repeatMode; }
    public void setRepeatMode(RepeatMode m) { this.repeatMode = m; }

    public void cycleRepeatMode() {
        switch (repeatMode) {
            case OFF: repeatMode = RepeatMode.ALL; break;
            case ALL: repeatMode = RepeatMode.ONE; break;
            case ONE: repeatMode = RepeatMode.OFF; break;
        }
    }

    public Song getCurrentSong() { return currentSong; }

    public boolean isPlaying() {
        try { return prepared && player.isPlaying(); } catch (Exception e) { return false; }
    }

    public void play(Song song) {
        if (song == null) return;
        try {
            player.reset();
            prepared = false;
            currentSong = song;
            player.setDataSource(context, song.getContentUri());
            player.prepareAsync();
        } catch (IOException | IllegalStateException | IllegalArgumentException e) {
            prepared = false;
            Log.e(TAG, "play failed", e);
            if (listener != null) {
                listener.onPlaybackStateChanged(false);
                listener.onPlaybackError("فشل فتح الملف: " + e.getMessage());
            }
        }
    }

    public void toggle() {
        if (!prepared) return;
        if (player.isPlaying()) {
            player.pause();
            stopProgressUpdates();
            if (listener != null) listener.onPlaybackStateChanged(false);
        } else {
            player.start();
            startProgressUpdates();
            if (listener != null) listener.onPlaybackStateChanged(true);
        }
    }

    public void pause() {
        if (prepared && player.isPlaying()) {
            player.pause();
            stopProgressUpdates();
            if (listener != null) listener.onPlaybackStateChanged(false);
        }
    }

    public void seekTo(int ms) {
        if (prepared) try { player.seekTo(ms); } catch (Exception ignored) {}
    }

    public void replayCurrent() { if (currentSong != null) play(currentSong); }

    private void startProgressUpdates() {
        handler.removeCallbacks(progressTask);
        handler.post(progressTask);
    }
    private void stopProgressUpdates() { handler.removeCallbacks(progressTask); }

    public void release() {
        stopProgressUpdates();
        try {
            if (player.isPlaying()) player.stop();
            player.release();
        } catch (Exception ignored) {}
    }
}
