package com.hussein.songzone;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import java.util.*;

public class MusicDatabase {
    private final List<Song> allSongs = new ArrayList<>();
    private final Context context;
    private boolean loaded = false;

    public MusicDatabase(Context c) { this.context = c.getApplicationContext(); }

    public void loadAll() {
        if (loaded) return;
        allSongs.clear();

        Uri collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DATA, MediaStore.Audio.Media.DURATION
        };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String sortOrder = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";
        ContentResolver cr = context.getContentResolver();

        try (Cursor c = cr.query(collection, projection, selection, null, sortOrder)) {
            if (c == null) return;
            int idI = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            int tI  = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
            int aI  = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
            int alI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
            int dI  = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA);
            int duI = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION);

            while (c.moveToNext()) {
                String title = c.getString(tI);
                String artist = c.getString(aI);
                String album = c.getString(alI);
                if (title == null || title.trim().isEmpty()) title = "بدون عنوان";
                if (artist == null || artist.trim().isEmpty() || "<unknown>".equalsIgnoreCase(artist))
                    artist = "فنان غير معروف";
                if (album == null || album.trim().isEmpty()) album = "ألبوم غير معروف";
                String path = c.getString(dI);
                if (path == null) path = "";
                allSongs.add(new Song(c.getLong(idI), title, artist, album, path, c.getLong(duI)));
            }
        } catch (SecurityException e) { loaded = false; return; }
        loaded = true;
    }

    public List<Song> getAll() { return new ArrayList<>(allSongs); }

    public List<Song> search(String q) {
        if (q == null || q.trim().isEmpty()) return getAll();
        String s = q.trim().toLowerCase(Locale.ROOT);
        List<Song> r = new ArrayList<>();
        for (Song so : allSongs) {
            if (so.getTitle().toLowerCase(Locale.ROOT).contains(s)
                || so.getArtist().toLowerCase(Locale.ROOT).contains(s)
                || so.getAlbum().toLowerCase(Locale.ROOT).contains(s)) r.add(so);
        }
        return r;
    }

    public boolean isEmpty() { return allSongs.isEmpty(); }
}
