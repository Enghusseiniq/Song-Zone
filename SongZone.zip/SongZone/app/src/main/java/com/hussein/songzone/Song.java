package com.hussein.songzone;

import android.content.ContentUris;
import android.net.Uri;
import android.provider.MediaStore;

public class Song {
    private final long id;
    private final String title, artist, album, path;
    private final long durationMs;

    public Song(long id, String title, String artist, String album, String path, long durationMs) {
        this.id = id; this.title = title; this.artist = artist;
        this.album = album; this.path = path; this.durationMs = durationMs;
    }
    public long getId() { return id; }
    public String getTitle() { return title; }
    public String getArtist() { return artist; }
    public String getAlbum() { return album; }
    public String getPath() { return path; }
    public long getDurationMs() { return durationMs; }

    public Uri getContentUri() {
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
    }
    public String getFormattedDuration() { return formatTime(durationMs); }

    public static String formatTime(long ms) {
        if (ms <= 0) return "00:00";
        long s = ms / 1000, h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sec);
        return String.format("%02d:%02d", m, sec);
    }
}
